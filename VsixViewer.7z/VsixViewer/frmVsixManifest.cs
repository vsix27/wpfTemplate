﻿using System;
using System.Windows.Forms;
using VsixViewer.ViewModels;

namespace VsixViewer
{
    public partial class frmVsixManifest : Form
    {
        private BindingSource Binding { get; set; } 
        public frmVsixManifest()
        {
            InitializeComponent();
        }

        private void frmVsixManifest_Load(object sender, EventArgs e)
        {
            Binding = new BindingSource {DataSource = typeof (ManifestModel)};
            //Binding.Add(new ManifestModel("Boeing 747", 800));
        }
    }
}
