﻿using System.Windows;
using VsixViewer.Helpers;
using VsixViewer.ViewModels;

namespace VsixViewer.Views
{
    /// <summary>
    /// Interaction logic for ManifestWindow.xaml
    /// </summary>
    public partial class ManifestWindow : Window
    {
        private readonly ManifestModel _viewModel;
  

        public ManifestWindow()
        {
            InitializeComponent();
            _viewModel = new ManifestModel();
            this.DataContext = _viewModel;
        }


        private void CommandCheckManifest(object sender, RoutedEventArgs e)
        {
            DebugHelper.DebugOpenHtml(_viewModel.ToStrings(), string.Empty, true);
            //Console.WriteLine(_viewModel.ToString());
        }

        private void ManifestSave(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            this.Close();
        }

        private void ManifestCancel(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            this.Close();
        }
    }
}
