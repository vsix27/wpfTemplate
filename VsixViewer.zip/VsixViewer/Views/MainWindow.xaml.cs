﻿using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using VsixViewer.Helpers;
using VsixViewer.ViewModels;

namespace VsixViewer.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        internal MainViewModel _viewModel;

        public MainWindow()
        {
            InitializeComponent();

            SeparatorLanguagesBefore.Visibility = Visibility.Visible;
            SeparatorLanguagesAfter.Visibility = Visibility.Visible;
            Languages.Visibility = Visibility.Visible;
            Languages.Header = ResourcesHelper.Instance.GetString("menuSetLanguage"); // english only


            var langs = Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory, "*.resources.dll", SearchOption.AllDirectories).Select(cf => Directory.GetParent(cf).Name).ToList();
            if (langs.Count > 0)
                langs.Add(CultureInfo.CurrentUICulture.Name);

            // var langs = new[] {"en-US","de-De", "ja-JP"};
            foreach (string slang in langs)
            {
                string display = CultureInfo.GetCultureInfo(slang).DisplayName;
                var newLanguage = new MenuItem { Header = display, Name = slang.Replace( '-','_') };
                newLanguage.Click += ChangeLanguage;
                if (slang.Equals("en-US"))
                {
                    newLanguage.IsChecked = true;
                    Languages.Header = string.Format("{0} [{1}]", ResourcesHelper.Instance.GetString("menuSetLanguage"), display);
                }
                Languages.Items.Add(newLanguage);
            }

            _viewModel = new MainViewModel();
            this.DataContext = _viewModel;
        }

        private void ChangeLanguage(object sender, RoutedEventArgs args)
        {
            var menuItem = args.Source as MenuItem;
            if (menuItem==null) return;

            foreach (MenuItem m in Languages.Items)
                m.IsChecked = false;

            var newLanguage = menuItem.Name.Replace('_', '-');
            ResourcesHelper.Instance.SetAppCulture(newLanguage);

            _viewModel.InitResources();  

            menuItem.IsChecked = true;
            Languages.Header = string.Format("{0} [{1}]", ResourcesHelper.Instance.GetString("menuSetLanguage"), ResourcesHelper.Instance.DisplayName);
        }

        public void ExitApplication(object sender, RoutedEventArgs e)
        {
            Window window = GetWindow(this);
            if (window != null)
                window.Close();
        }        
    }
}
