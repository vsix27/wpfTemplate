﻿using System.ComponentModel;

namespace VsixViewer.ViewModels
{
    /// <summary>
    /// properties used in presenter
    /// </summary>
    public interface IMainViewModel
    {
        event PropertyChangedEventHandler PropertyChanged;
        string FolderPath { get; set; }
        string OutputText { get; set; }
        string ErrorText { get; set; }
        string VsixPath { get; set; }
        string VsixPathUnpacked { get; set; }
    }
}
